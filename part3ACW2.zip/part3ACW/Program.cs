﻿namespace part3ACW
{
    interface IcustomerOrder
    {
        // base flavours interface
         void baseFlavours();
        
    }
    interface Itoppings
    {
         void toppingFLavours();
    }
    class CustomerOrder : program, IcustomerOrder, Itoppings
    {
        
        
        public void baseFlavours()
        {
            Console.WriteLine("please choose a flavour from 1 to 3");
            Console.WriteLine("1. original");
            Console.WriteLine("2. chocolate");
            Console.WriteLine("3. vanilla");
            
        
        }
       
        public void toppingFLavours()
        {
            Console.WriteLine("please choose a topping from 1 to 4");
            Console.WriteLine("1. choc syrup");
            Console.WriteLine("2. fresh fruit");
            Console.WriteLine("3. sprinkles");
            Console.WriteLine("4. granola");
            
        }

        
    }
    

    
    
    public class program 
    {
        
        public static void Main()
        {
            /* ask base yoghurt
             * list toppings and price and ask what they would like, can have multiple answers so ask recurringly
             * ask if they want to double their portion size, act accordingly
             * need to use the name of toppings saved so can give reciept
             * make new objects each like in shapeprodigy
             * store in txt file if i have time but focus on error handling for the extra point
             * conststring for persistent pricing, or could use privatte string, does it make a diff?
             */
            CustomerOrder newOrder = new CustomerOrder();
            double totalCost = 0;
            string mainFlavour;
            string portion = "";

            void options() // user chooses their topping flavours
            {
                Console.WriteLine("would you like any more toppings? y/n");
                string? optionAnswer = Console.ReadLine();
                if (optionAnswer == "y")
                {
                    toppingflav();
                    return;
                }
                if (optionAnswer == "n")
                {
                    return;
                }
                else
                {
                    Console.WriteLine("please enter a valid input");
                    options();
                }
            }
            void baseflav()
            { // the main flavours of the yoghurt
                 
                newOrder.baseFlavours();
                int answer = Convert.ToInt32(Console.ReadLine());
                if (answer == 1)
                {
                    mainFlavour = "orignal";
                    totalCost = totalCost + 3.00;
                    return;

                }
                if (answer == 2)
                {
                    mainFlavour = "chocolate";
                    totalCost = totalCost + 3.00;
                    return;
                }
                if (answer == 3)
                {
                    mainFlavour = "vanilla";
                    totalCost = totalCost + 3.00;
                    return;
                }
                else
                {
                    Console.WriteLine("please enter valid input");
                    baseflav();

                }
            }

            List<string> list = new List<string>();
            void toppingflav()
            {
                // the topping flavours
                newOrder.toppingFLavours();
                int answer2 = Convert.ToInt32(Console.ReadLine());
                if (answer2 == 1)
                {
                    list.Add("choc syrup");
                    totalCost = totalCost + 0.50;
                    options();
                    return;

                }
                if (answer2 == 2)
                {
                    list.Add("fruit");
                    totalCost = totalCost + 1.50;
                    options();
                    return;
                }
                if (answer2 == 3)
                {
                    list.Add("sprinkles");
                    totalCost = totalCost + 0.80;
                    options();
                    return;

                }
                if (answer2 == 4)
                {
                    list.Add("granola");
                    totalCost = totalCost + 1.00;
                    options();
                    return;
                }

                else
                {
                    Console.WriteLine("please enter valid input");
                    toppingflav();
                    return;
                }
            }

            void portionSize() //choosing the portion size
            {
                Console.WriteLine("would you like to double your portion size?y/n");
                string? optionAnswer = Console.ReadLine();
                if (optionAnswer == "y")
                {
                    totalCost *= 2;
                    portion = "double";
                    return;
                }
                if (optionAnswer == "n")
                {
                    portion = "single";
                    Console.WriteLine("okay");
                    return;
                }
                else
                {
                    Console.WriteLine("please enter a valid input");
                    return;
                }
            }
            
            // user intereactions happen here
            Console.WriteLine("welcome to the shop");
            baseflav();
            toppingflav();
            portionSize();

            Console.WriteLine("----------------------");
            Console.WriteLine("thanks you, you ordered:  " + mainFlavour + " flavour " +"\nwith portion size: "+ portion +  "\nwith the sides: ");
            foreach (string l in list)
            {
                Console.WriteLine(l);
            }
            
            Console.WriteLine("\nand your total cost is: £" + totalCost);

            
        }
    }

}