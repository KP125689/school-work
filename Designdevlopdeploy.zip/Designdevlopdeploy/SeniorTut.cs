﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designdevlopdeploy
{
    public class SeniorTut : Staff
    {

       public void viewStatus()
        {
            studentView();
            Console.WriteLine("the student you are viewing has a score of " + feelingsScore);
            // senior tutor just views 
        }
    }
}
