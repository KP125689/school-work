﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;

namespace Designdevlopdeploy
{
    public class Staff : universityMembers
    {
        public void studentView()
        {
            string path = "C:/Users/patrw/source/repos/Designdevlopdeploy/dddcsv.csv";
            //file path
            
            string[] lines = File.ReadAllLines(path, Encoding.UTF8);
            
            foreach (string line in lines)
            {
                Console.WriteLine(line);
                //show all users
            }
            

            Console.WriteLine("please enter the Id of the student you want to view");
            string? studentID = Console.ReadLine();
            if (lines.Contains(studentID))
            {
                //views progress score of user chosen
                Console.WriteLine(studentID);
                viewProgress();
            }
            if(lines.Contains(studentID!))
            {
                Console.WriteLine("please enter a valid ID");
                studentView(); 
            }
        }

        public void viewProgress()
        {
            // view student progress score
            Console.WriteLine("the student has a feelings score of " + feelingsScore);

        }

        

    }
}
