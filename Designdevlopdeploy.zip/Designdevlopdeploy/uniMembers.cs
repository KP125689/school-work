﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;

namespace Designdevlopdeploy
{

    public class universityMembers : Program
    {
        
        string path = "C:/Users/patrw/source/repos/Designdevlopdeploy/dddcsv.csv";
        private int ID;
        public int id
        {
            get { return ID; }
        }

        public string? meetingDate;
        public int feelingsScore;

        public void StartingQuestion()
        {
            // first question at start of program
            Console.WriteLine("are you student or staff?");
            string? answer1 = Console.ReadLine();
            if (answer1 == "student")
            {
                // follow student pathway
                studentPath();
                return;
            }
            if (answer1 == "staff")
            {
                // follow staff pathway
                staffPath();
                return;
            }
            else
            {
                Console.WriteLine("please enter a valid answer");
                StartingQuestion();
            }
        }

      

         public void fileHanding(string? userInfo)
        {
            using (var stream = File.Open(path, FileMode.Append))
            using (var writer = new StreamWriter(stream))
            {
                writer.Write(userInfo + ", ");
                // opens file and writes the user inputs
              

            }
        }

        public void SetID()
        {
            // create ID
            Random rnd = new Random();
            ID = rnd.Next(0,100);
            string userID = ID.ToString();
            
            fileHanding(userID);
        }

        public void setFirstName()
        {
            Console.WriteLine("what is your first name?");
            string? FirstName = Console.ReadLine();
            fileHanding(FirstName);
            
        }

        public void setLastNamae()
        {
            Console.WriteLine("what's your last name?");
            string? LastName = Console.ReadLine();
            fileHanding(LastName);
        }
        

        public void bookMeeting()
        {
            //asks user if they want to book a meeting
            Console.WriteLine("would you like to book a meeting? (y/n)");
            string? answer1 = Console.ReadLine();
            if (answer1 == "y")
            {
                Console.WriteLine("alright please choose a date in DD-MM-YYYY format");
                string? userDate = Console.ReadLine();
                userDate = meetingDate;
                Console.WriteLine("thank you for booking a meeting at date: " + meetingDate);
                Console.WriteLine("\n" );
                Console.WriteLine("we will now notify your personal supervisor");
                fileHanding("the usere has booked a meeting for " + userDate);
                return;
            }
            if (answer1 == "n")
            {
                Console.WriteLine("okay");
                return;
            }
            else
            {
                Console.WriteLine("please enter a valid answer");
                bookMeeting();
            }
            
        }


        public void studentPath()
        {
            //creating student object and sequences of questions for student
            Students newStu = new Students();
            newStu.SetID();
            newStu.setFirstName();
            newStu.setLastNamae();
            newStu.CurrentProgress();
            newStu.bookMeeting();

        }

        public void staffPath()
        {
            //creating staff objects and sequences of questions for staff
            Console.WriteLine("are you a PS or ST? ");
            string? answer3 = Console.ReadLine();
            
            if (answer3 == "PS")
            {
                personalSup PS = new personalSup();
                PS.studentView();
                PS.viewProgress();
                PS.requestMeeting();
                return;

            }
            if (answer3 == "ST")
            {
                SeniorTut seniorTut = new SeniorTut();
                seniorTut.viewStatus();
                return;
            }
            else
            {
                Console.WriteLine("please enter a valid answer");
                staffPath();
                return;
            }

        }

    }

    
    
}

