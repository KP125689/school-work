﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designdevlopdeploy
{
    public class Students : universityMembers
    {
        

        public void CurrentProgress()
        {
            // asking the student for their feeling score
            Console.WriteLine("on a scale of 1-10, how are you feeling about your course?");
            string? ratings = Console.ReadLine();
            int ratingsScore = Convert.ToInt32(ratings);

            if (ratingsScore > 0 && ratingsScore < 11)
            {
                // stores users score in CSV file
                Console.WriteLine("thank you for your feedback");
                ratingsScore = feelingsScore;
                fileHanding("Score: " + feelingsScore);
            }
            else
            {
                Console.WriteLine("please enter a valid number");
                CurrentProgress();
                
            }

        }

        

        
    }
}
