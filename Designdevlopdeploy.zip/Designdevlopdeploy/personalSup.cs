﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designdevlopdeploy
{
    public class personalSup : Staff
    {
        public void requestMeeting()
        {
            // ask to make meeting with student
            Console.WriteLine("would you like to book a meeting with this student?(y/n)");
            string? meetingAnswer = Console.ReadLine();
            if (meetingAnswer == "y")
            {
                Console.WriteLine("okay we will send a request to the student...");
                Console.WriteLine("...");
                return;
            }
            if (meetingAnswer == "n")
            {
                Console.WriteLine("okay");
                return;
            }
            else
            {
                Console.WriteLine("please enter a valid answer");
                requestMeeting();
                
            }

        }

        public void studentAnswer()
        {
            Console.WriteLine("your Personal supervisor would like to book a meeting with you. do you accept (y/n)");
            string? answer2 = Console.ReadLine();

            if (answer2 == "y")
            {
                //do stuff
            }
            if (answer2 == "n")
            {
                Console.WriteLine("okay, thank you for your feedback");
            }
            else
            {
                Console.WriteLine("please enter a valid answer");
                studentAnswer();
            }
        }

       
        public void receiveRequest()
        {
            // receive the students reqquest for a meeting 
        
            Console.WriteLine("you've received a meeting request from student " + id);
            Console.WriteLine("they have booked it for "+ meetingDate);
        }

       
    }
}
