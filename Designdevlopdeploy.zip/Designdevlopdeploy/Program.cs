﻿using System;
using MySQL.Data;
using MySql.Data.MySqlClient;
using CsvHelper;

namespace Designdevlopdeploy
{
    public class Program 
    {

        
        public static void Main()
        {
            //start of program
            universityMembers newstart = new universityMembers();
            newstart.StartingQuestion();
        }
        
        

    }


}